name: "Collab"
designer: "Yugal"
license: "OFL"
category: "SANS_SERIF"
date_added: "2026-11-01"
fonts {
  name: "Collab"
  style: "normal"
  weight: 100
  filename: "Collab-Thin.ttf"
  post_script_name: "Collab-Thin"
  full_name: "Collab Thin"
  copyright: "Copyright 2026 The Collab Project Authors (https://github.com/yugal/collab), with Reserved Font Name \"Collab\". Copyright 2016-2024 The Inter Project Authors (https://github.com/rsms/inter)"
}
fonts {
  name: "Collab"
  style: "italic"
  weight: 100
  filename: "Collab-ThinItalic.ttf"
  post_script_name: "Collab-ThinItalic"
  full_name: "Collab Thin Italic"
  copyright: "Copyright 2026 The Collab Project Authors (https://github.com/yugal/collab), with Reserved Font Name \"Collab\". Copyright 2016-2024 The Inter Project Authors (https://github.com/rsms/inter)"
}
fonts {
  name: "Collab"
  style: "normal"
  weight: 200
  filename: "Collab-ExtraLight.ttf"
  post_script_name: "Collab-ExtraLight"
  full_name: "Collab ExtraLight"
  copyright: "Copyright 2026 The Collab Project Authors (https://github.com/yugal/collab), with Reserved Font Name \"Collab\". Copyright 2016-2024 The Inter Project Authors (https://github.com/rsms/inter)"
}
fonts {
  name: "Collab"
  style: "italic"
  weight: 200
  filename: "Collab-ExtraLightItalic.ttf"
  post_script_name: "Collab-ExtraLightItalic"
  full_name: "Collab ExtraLight Italic"
  copyright: "Copyright 2026 The Collab Project Authors (https://github.com/yugal/collab), with Reserved Font Name \"Collab\". Copyright 2016-2024 The Inter Project Authors (https://github.com/rsms/inter)"
}
fonts {
  name: "Collab"
  style: "normal"
  weight: 300
  filename: "Collab-Light.ttf"
  post_script_name: "Collab-Light"
  full_name: "Collab Light"
  copyright: "Copyright 2026 The Collab Project Authors (https://github.com/yugal/collab), with Reserved Font Name \"Collab\". Copyright 2016-2024 The Inter Project Authors (https://github.com/rsms/inter)"
}
fonts {
  name: "Collab"
  style: "italic"
  weight: 300
  filename: "Collab-LightItalic.ttf"
  post_script_name: "Collab-LightItalic"
  full_name: "Collab Light Italic"
  copyright: "Copyright 2026 The Collab Project Authors (https://github.com/yugal/collab), with Reserved Font Name \"Collab\". Copyright 2016-2024 The Inter Project Authors (https://github.com/rsms/inter)"
}
fonts {
  name: "Collab"
  style: "normal"
  weight: 400
  filename: "Collab-Regular.ttf"
  post_script_name: "Collab-Regular"
  full_name: "Collab Regular"
  copyright: "Copyright 2026 The Collab Project Authors (https://github.com/yugal/collab), with Reserved Font Name \"Collab\". Copyright 2016-2024 The Inter Project Authors (https://github.com/rsms/inter)"
}
fonts {
  name: "Collab"
  style: "italic"
  weight: 400
  filename: "Collab-Italic.ttf"
  post_script_name: "Collab-Italic"
  full_name: "Collab Italic"
  copyright: "Copyright 2026 The Collab Project Authors (https://github.com/yugal/collab), with Reserved Font Name \"Collab\". Copyright 2016-2024 The Inter Project Authors (https://github.com/rsms/inter)"
}
fonts {
  name: "Collab"
  style: "normal"
  weight: 500
  filename: "Collab-Medium.ttf"
  post_script_name: "Collab-Medium"
  full_name: "Collab Medium"
  copyright: "Copyright 2026 The Collab Project Authors (https://github.com/yugal/collab), with Reserved Font Name \"Collab\". Copyright 2016-2024 The Inter Project Authors (https://github.com/rsms/inter)"
}
fonts {
  name: "Collab"
  style: "italic"
  weight: 500
  filename: "Collab-MediumItalic.ttf"
  post_script_name: "Collab-MediumItalic"
  full_name: "Collab Medium Italic"
  copyright: "Copyright 2026 The Collab Project Authors (https://github.com/yugal/collab), with Reserved Font Name \"Collab\". Copyright 2016-2024 The Inter Project Authors (https://github.com/rsms/inter)"
}
fonts {
  name: "Collab"
  style: "normal"
  weight: 600
  filename: "Collab-SemiBold.ttf"
  post_script_name: "Collab-SemiBold"
  full_name: "Collab SemiBold"
  copyright: "Copyright 2026 The Collab Project Authors (https://github.com/yugal/collab), with Reserved Font Name \"Collab\". Copyright 2016-2024 The Inter Project Authors (https://github.com/rsms/inter)"
}
fonts {
  name: "Collab"
  style: "italic"
  weight: 600
  filename: "Collab-SemiBoldItalic.ttf"
  post_script_name: "Collab-SemiBoldItalic"
  full_name: "Collab SemiBold Italic"
  copyright: "Copyright 2026 The Collab Project Authors (https://github.com/yugal/collab), with Reserved Font Name \"Collab\". Copyright 2016-2024 The Inter Project Authors (https://github.com/rsms/inter)"
}
fonts {
  name: "Collab"
  style: "normal"
  weight: 700
  filename: "Collab-Bold.ttf"
  post_script_name: "Collab-Bold"
  full_name: "Collab Bold"
  copyright: "Copyright 2026 The Collab Project Authors (https://github.com/yugal/collab), with Reserved Font Name \"Collab\". Copyright 2016-2024 The Inter Project Authors (https://github.com/rsms/inter)"
}
fonts {
  name: "Collab"
  style: "italic"
  weight: 700
  filename: "Collab-BoldItalic.ttf"
  post_script_name: "Collab-BoldItalic"
  full_name: "Collab Bold Italic"
  copyright: "Copyright 2026 The Collab Project Authors (https://github.com/yugal/collab), with Reserved Font Name \"Collab\". Copyright 2016-2024 The Inter Project Authors (https://github.com/rsms/inter)"
}
fonts {
  name: "Collab"
  style: "normal"
  weight: 800
  filename: "Collab-ExtraBold.ttf"
  post_script_name: "Collab-ExtraBold"
  full_name: "Collab ExtraBold"
  copyright: "Copyright 2026 The Collab Project Authors (https://github.com/yugal/collab), with Reserved Font Name \"Collab\". Copyright 2016-2024 The Inter Project Authors (https://github.com/rsms/inter)"
}
fonts {
  name: "Collab"
  style: "italic"
  weight: 800
  filename: "Collab-ExtraBoldItalic.ttf"
  post_script_name: "Collab-ExtraBoldItalic"
  full_name: "Collab ExtraBold Italic"
  copyright: "Copyright 2026 The Collab Project Authors (https://github.com/yugal/collab), with Reserved Font Name \"Collab\". Copyright 2016-2024 The Inter Project Authors (https://github.com/rsms/inter)"
}
fonts {
  name: "Collab"
  style: "normal"
  weight: 900
  filename: "Collab-Black.ttf"
  post_script_name: "Collab-Black"
  full_name: "Collab Black"
  copyright: "Copyright 2026 The Collab Project Authors (https://github.com/yugal/collab), with Reserved Font Name \"Collab\". Copyright 2016-2024 The Inter Project Authors (https://github.com/rsms/inter)"
}
fonts {
  name: "Collab"
  style: "italic"
  weight: 900
  filename: "Collab-BlackItalic.ttf"
  post_script_name: "Collab-BlackItalic"
  full_name: "Collab Black Italic"
  copyright: "Copyright 2026 The Collab Project Authors (https://github.com/yugal/collab), with Reserved Font Name \"Collab\". Copyright 2016-2024 The Inter Project Authors (https://github.com/rsms/inter)"
}
subsets: "cyrillic"
subsets: "cyrillic-ext"
subsets: "greek"
subsets: "greek-ext"
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
subsets: "vietnamese"
